/**
 * xload Retro System Monitor - Chrome Popup Controller
 */

let config = {
  theme: 'classic',
  refreshRate: 1000,
  showGrid: true,
  scanlines: true
};

let history = [];
const maxDataPoints = 120;
let prevCpuInfo = null;
let updateIntervalId = null;
let pendingCpuQuery = false;
let pendingMemoryQuery = false;
let historyDirty = false;
let lastHistoryPersist = 0;
const historyPersistIntervalMs = 1000;

const canvas = document.getElementById('xload-canvas');
const ctx = canvas.getContext('2d');

const themeSelect = document.getElementById('theme-select');
const intervalSelect = document.getElementById('interval-select');
const gridToggle = document.getElementById('grid-toggle');
const scanlinesToggle = document.getElementById('scanlines-toggle');
const loadValueEl = document.getElementById('load-value');
const scaleValueEl = document.getElementById('scale-value');
const memoryValueEl = document.getElementById('memory-value');
const scanlineOverlayEl = document.querySelector('.scanlines');

/**
 * All visible text comes from _locales/<language>/messages.json through chrome.i18n, which
 * resolves it against Chrome's own language setting: English or French, with the English
 * catalog as the fallback for every other browser language.
 */
const t = (key, substitutions) => chrome.i18n.getMessage(key, substitutions) || key;

/**
 * Numbers follow the catalog, not JavaScript: a French readout is written 21,46 % where the
 * English one is 21.46%. The separator is itself a message, so a --catalog capture and a real
 * French Chrome format a value the same way instead of trusting the page's language.
 */
const decimalSeparator = t('decimalSeparator');
const formatNumber = (value, decimals) => {
  const [whole, fraction] = Number(value).toFixed(decimals).split('.');
  return fraction ? `${whole}${decimalSeparator}${fraction}` : whole;
};

function localizeUi() {
  document.documentElement.lang = chrome.i18n.getUILanguage();

  for (const element of document.querySelectorAll('[data-i18n]')) {
    element.textContent = t(element.dataset.i18n);
  }
}

const themes = {
  'classic': { bg: '#ffffff', grid: '#dfdfdf', line: '#ff0000', fill: 'rgba(255, 0, 0, 0.15)', border: '#000000', text: '#000000' },
  'retro-dark': { bg: '#121214', grid: '#1a243a', line: '#00e1d9', fill: 'rgba(0, 225, 217, 0.12)', border: '#00e1d9', text: '#00e1d9' },
  'amber-crt': { bg: '#150900', grid: '#3a1b00', line: '#ff8100', fill: 'rgba(255, 129, 0, 0.12)', border: '#ff8100', text: '#ff8100' },
  'matrix-green': { bg: '#020d00', grid: '#003c00', line: '#15ff00', fill: 'rgba(21, 255, 0, 0.15)', border: '#15ff00', text: '#15ff00' },
  'vapor-cyber': { bg: '#1b001d', grid: '#44005c', line: '#ff0055', fill: 'rgba(255, 0, 85, 0.15)', border: '#ff0055', text: '#ff0055' },
  'mono-high': { bg: '#000000', grid: '#333333', line: '#ffffff', fill: 'rgba(255, 255, 255, 0.12)', border: '#ffffff', text: '#ffffff' }
};

document.addEventListener('DOMContentLoaded', () => {
  ctx.imageSmoothingEnabled = false;
  localizeUi();

  chrome.storage.local.get(['config', 'history'], (result) => {
    if (result.config) config = { ...config, ...result.config };
    if (result.history) history = result.history;

    themeSelect.value = config.theme;

    const rateValues = Array.from(intervalSelect.options, (option) => option.value);
    if (rateValues.includes(String(config.refreshRate))) {
      intervalSelect.value = String(config.refreshRate);
    } else {
      config.refreshRate = parseInt(intervalSelect.value, 10) || 1000;
    }

    gridToggle.checked = config.showGrid;
    scanlinesToggle.checked = config.scanlines;

    if (history.length > 0) {
      loadValueEl.textContent = t('loadPercent', [formatNumber(history[history.length - 1], 2)]);
    }

    updateScanlineOverlay();
    startMonitoringLoop();
    drawGraph();

    document.addEventListener('pagehide', flushHistory);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') flushHistory();
    });

    themeSelect.addEventListener('change', (e) => {
      config.theme = e.target.value;
      saveConfig();
      drawGraph();
    });

    intervalSelect.addEventListener('change', (e) => {
      config.refreshRate = parseInt(e.target.value, 10);
      saveConfig();
      startMonitoringLoop();
    });

    gridToggle.addEventListener('change', (e) => {
      config.showGrid = e.target.checked;
      saveConfig();
      drawGraph();
    });

    scanlinesToggle.addEventListener('change', (e) => {
      config.scanlines = e.target.checked;
      updateScanlineOverlay();
      saveConfig();
    });
  });
});

function updateScanlineOverlay() {
  scanlineOverlayEl.style.display = config.scanlines ? 'block' : 'none';
}

function saveConfig() {
  chrome.storage.local.set({ config }, () => {
    if (chrome.runtime.lastError) {
      console.warn('xload: could not save config:', chrome.runtime.lastError.message);
    }
  });
}

function flushHistory() {
  persistHistory(true);
}

function persistHistory(force = false) {
  if (!historyDirty) return;

  const now = Date.now();
  if (!force && now - lastHistoryPersist < historyPersistIntervalMs) return;

  lastHistoryPersist = now;
  historyDirty = false;
  chrome.storage.local.set({ history }, () => {
    if (chrome.runtime.lastError) {
      historyDirty = true;
      console.warn('xload: could not persist history:', chrome.runtime.lastError.message);
    }
  });
}

function startMonitoringLoop() {
  if (updateIntervalId) clearInterval(updateIntervalId);
  queryCpuInfo();
  queryMemoryInfo();
  updateIntervalId = setInterval(() => {
    queryCpuInfo();
    queryMemoryInfo();
  }, config.refreshRate);
}

function queryCpuInfo() {
  if (pendingCpuQuery) return;
  pendingCpuQuery = true;

  chrome.system.cpu.getInfo((cpuInfo) => {
    pendingCpuQuery = false;
    if (chrome.runtime.lastError) {
      console.warn('xload: chrome.system.cpu.getInfo failed:', chrome.runtime.lastError.message);
      return;
    }
    if (!cpuInfo) return;
    if (prevCpuInfo) {
      let activeTicksDiff = 0;
      let totalTicksDiff = 0;

      for (let i = 0; i < cpuInfo.processors.length; i++) {
        const pNow = cpuInfo.processors[i].usage;
        const pPrior = prevCpuInfo.processors[i] ? prevCpuInfo.processors[i].usage : null;
        if (pPrior) {
          const nowActive = pNow.user + pNow.kernel;
          const nowTotal = pNow.user + pNow.kernel + pNow.idle;
          const priorActive = pPrior.user + pPrior.kernel;
          const priorTotal = pPrior.user + pPrior.kernel + pPrior.idle;

          activeTicksDiff += (nowActive - priorActive);
          totalTicksDiff += (nowTotal - priorTotal);
        }
      }

      let loadPercent = 0;
      if (totalTicksDiff > 0) {
        loadPercent = (activeTicksDiff / totalTicksDiff) * 100;
      }
      loadPercent = Math.max(0, Math.min(100, loadPercent));
      history.push(loadPercent);
      if (history.length > maxDataPoints) history.shift();
      historyDirty = true;

      loadValueEl.textContent = t('loadPercent', [formatNumber(loadPercent, 2)]);
      persistHistory();
      drawGraph();
    }
    prevCpuInfo = cpuInfo;
  });
}

/**
 * System memory in use, as a percentage of installed RAM. One call, no history: memory moves
 * slowly enough that a readout is enough, and the graph stays a CPU graph.
 */
function queryMemoryInfo() {
  if (pendingMemoryQuery) return;
  pendingMemoryQuery = true;

  chrome.system.memory.getInfo((memoryInfo) => {
    pendingMemoryQuery = false;
    if (chrome.runtime.lastError) {
      console.warn('xload: chrome.system.memory.getInfo failed:', chrome.runtime.lastError.message);
      return;
    }
    if (!memoryInfo || !memoryInfo.capacity) return;
    const usedPercent = ((memoryInfo.capacity - memoryInfo.availableCapacity) / memoryInfo.capacity) * 100;
    const clamped = Math.max(0, Math.min(100, usedPercent));
    memoryValueEl.textContent = t('memoryPercent', [formatNumber(Math.round(clamped), 0)]);
  });
}

function drawGraph() {
  const currentTheme = themes[config.theme] || themes['classic'];
  const w = canvas.width;
  const h = canvas.height;

  ctx.fillStyle = currentTheme.bg;
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = currentTheme.border;
  ctx.strokeRect(0.5, 0.5, w - 1, h - 1);

  let maxLoadVal = 20;
  for (const p of history) {
    if (p > maxLoadVal) maxLoadVal = p;
  }
  maxLoadVal = Math.ceil(maxLoadVal / 10) * 10;
  if (maxLoadVal > 100) maxLoadVal = 100;

  scaleValueEl.textContent = t('scaleMax', [String(maxLoadVal)]);

  if (config.showGrid) {
    ctx.strokeStyle = currentTheme.grid;
    ctx.setLineDash([2, 3]);
    const colWidth = w / 5;
    for (let i = 1; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.floor(i * colWidth) + 0.5, 0);
      ctx.lineTo(Math.floor(i * colWidth) + 0.5, h);
      ctx.stroke();
    }
    const rowHeight = h / 4;
    for (let i = 1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(0, Math.floor(i * rowHeight) + 0.5);
      ctx.lineTo(w, Math.floor(i * rowHeight) + 0.5);
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  if (history.length > 1) {
    const step = (w - 2) / (maxDataPoints - 1);
    ctx.beginPath();
    ctx.moveTo(1, h - 1);
    for (let i = 0; i < history.length; i++) {
      const val = history[i];
      const x = 1 + i * step;
      const normY = val / maxLoadVal;
      const y = h - 1 - (normY * (h - 2));
      ctx.lineTo(x, y);
    }
    ctx.lineTo(1 + (history.length - 1) * step, h - 1);
    ctx.closePath();

    ctx.fillStyle = currentTheme.fill;
    ctx.fill();

    ctx.beginPath();
    for (let i = 0; i < history.length; i++) {
      const val = history[i];
      const x = 1 + i * step;
      const normY = val / maxLoadVal;
      const y = h - 1 - (normY * (h - 2));
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = currentTheme.line;
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}